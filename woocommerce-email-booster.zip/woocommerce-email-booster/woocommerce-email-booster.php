<?php
/*
Plugin Name: WooCommerce Email Booster
Plugin URI: https://www.linkedin.com/in/arindam-mallick/
Description: Fix WooCommerce emails with Razorpay Magic Checkout + Fluent SMTP + AiSensy. Includes email triggers, settings, and logs.
Version: 1.0
Author: Arindam Mallick
Author URI: https://www.linkedin.com/in/arindam-mallick/
License: GPLv2 or later
Text Domain: woocommerce-email-booster
*/


if (!defined('ABSPATH')) {
    exit;
}

// Load plugin
add_action('plugins_loaded', 'webooster_init');
function webooster_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="error"><p><strong>WooCommerce Email Booster</strong> requires WooCommerce to be installed and active.</p></div>';
        });
        return;
    }
}

// Add Settings Menu
add_action('admin_menu', 'webooster_settings_menu');
function webooster_settings_menu() {
    add_menu_page(
        'Email Booster',
        'Email Booster',
        'manage_options',
        'webooster-settings',
        'webooster_settings_page',
        'dashicons-email-alt',
        56
    );
}

// Settings Page UI
function webooster_settings_page() {
    ?>
    <div class="wrap">
        <h1>WooCommerce Email Booster</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('webooster_settings_group');
                do_settings_sections('webooster-settings');
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register Settings
add_action('admin_init', 'webooster_register_settings');
function webooster_register_settings() {
    register_setting('webooster_settings_group', 'webooster_enabled_emails');

    add_settings_section('webooster_main_section', 'Email Notifications', null, 'webooster-settings');

    $emails = [
        'WC_Email_New_Order' => 'Admin: New Order',
        'WC_Email_Customer_Processing_Order' => 'Customer: Processing Order',
        'WC_Email_Customer_Completed_Order' => 'Customer: Completed Order',
        'WC_Email_Customer_On_Hold_Order' => 'Customer: On Hold Order',
        'WC_Email_Customer_Refunded_Order' => 'Customer: Refunded Order',
        'WC_Email_Failed_Order' => 'Admin: Failed Order'
    ];

    foreach ($emails as $id => $label) {
        add_settings_field(
            $id,
            $label,
            'webooster_checkbox_field',
            'webooster-settings',
            'webooster_main_section',
            ['id' => $id]
        );
    }
}

// Checkbox UI
function webooster_checkbox_field($args) {
    $enabled_emails = get_option('webooster_enabled_emails', []);
    $checked = in_array($args['id'], (array)$enabled_emails) ? 'checked' : '';
    echo "<input type='checkbox' name='webooster_enabled_emails[]' value='{$args['id']}' {$checked} />";
}

// Hook into Order Status Change
add_action('woocommerce_order_status_changed', 'webooster_trigger_emails', 10, 4);
function webooster_trigger_emails($order_id, $old_status, $new_status, $order) {
    if (!$order_id || !$order) return;

    $enabled_emails = get_option('webooster_enabled_emails', []);
    if (empty($enabled_emails)) return;

    $mailer = WC()->mailer();

    foreach ($enabled_emails as $email_id) {
        if (isset($mailer->emails[$email_id])) {
            $mailer->emails[$email_id]->trigger($order_id);
            webooster_log_email($order_id, $email_id, $new_status);
        }
    }
}

// Email Logging
function webooster_log_email($order_id, $email_id, $status) {
    $log_file = plugin_dir_path(__FILE__) . 'email-log.txt';
    $time = date('Y-m-d H:i:s');
    $log_entry = "[{$time}] Order ID: {$order_id}, Email: {$email_id}, Status: {$status}\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

// Add Logs Viewer in Settings
add_action('admin_menu', function() {
    add_submenu_page(
        'webooster-settings',
        'Email Logs',
        'Email Logs',
        'manage_options',
        'webooster-email-logs',
        'webooster_show_logs'
    );
});

function webooster_show_logs() {
    $log_file = plugin_dir_path(__FILE__) . 'email-log.txt';
    echo '<div class="wrap"><h1>Email Logs</h1><pre>';
    if (file_exists($log_file)) {
        echo esc_html(file_get_contents($log_file));
    } else {
        echo 'No email logs available yet.';
    }
    echo '</pre></div>';
}
